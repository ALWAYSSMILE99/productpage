import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kidstoys',
  templateUrl: './kidstoys.component.html',
  styleUrls: ['./kidstoys.component.css']
})
export class KidstoysComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
