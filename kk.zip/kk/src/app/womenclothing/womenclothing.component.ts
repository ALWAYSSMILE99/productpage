import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-womenclothing',
  templateUrl: './womenclothing.component.html',
  styleUrls: ['./womenclothing.component.css']
})
export class WomenclothingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
