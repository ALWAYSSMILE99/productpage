import { BrowserModule,Title } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{HttpClient,HttpClientModule}from '@angular/common/http'; 
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MenComponent } from './men/men.component';
import { WomenComponent } from './women/women.component';
import { KidsComponent } from './kids/kids.component';
import {FormsModule} from '@angular/forms';
import { MenwatchesComponent } from './menwatches/menwatches.component';
import { MenclothesComponent } from './menclothes/menclothes.component';
import { MenaccessoriesComponent } from './menaccessories/menaccessories.component';
import { MenfootwearComponent } from './menfootwear/menfootwear.component';
import { KidsclothesComponent } from './kidsclothes/kidsclothes.component';
import { KidsfootwearComponent } from './kidsfootwear/kidsfootwear.component';
import { KidstoysComponent } from './kidstoys/kidstoys.component';
import { KidsaccessoriesComponent } from './kidsaccessories/kidsaccessories.component';
import{WomenaccessoriesComponent} from 'src/app/womenaccessories/womenaccessories.component';
import{WomenclothingComponent} from 'src/app/womenclothing/womenclothing.component';
import{WomenfootwearComponent} from 'src/app/womenfootwear/womenfootwear.component';
import{WomenwatchesComponent} from 'src/app/womenwatches/womenwatches.component';
import { ViewdescriptionComponent } from './viewdescription/viewdescription.component';

@NgModule({
  declarations: [
    AppComponent,
    MenComponent,
    WomenComponent,
    KidsComponent,
    MenwatchesComponent,
    MenclothesComponent,
    MenaccessoriesComponent,
    MenfootwearComponent,
    KidsclothesComponent,
    KidsfootwearComponent,
    KidstoysComponent,
    KidsaccessoriesComponent,
    WomenaccessoriesComponent,
    WomenclothingComponent,
    WomenfootwearComponent,
    WomenwatchesComponent,
    ViewdescriptionComponent


  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [HttpClient,Title],
  bootstrap: [AppComponent]
})
export class AppModule { }
