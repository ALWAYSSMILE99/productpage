import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menaccessories',
  templateUrl: './menaccessories.component.html',
  styleUrls: ['./menaccessories.component.css']
})
export class MenaccessoriesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
