import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kidsclothes',
  templateUrl: './kidsclothes.component.html',
  styleUrls: ['./kidsclothes.component.css']
})
export class KidsclothesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
