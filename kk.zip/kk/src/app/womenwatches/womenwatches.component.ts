import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-womenwatches',
  templateUrl: './womenwatches.component.html',
  styleUrls: ['./womenwatches.component.css']
})
export class WomenwatchesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
