import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MenwatchesComponent } from './menwatches.component';

describe('MenwatchesComponent', () => {
  let component: MenwatchesComponent;
  let fixture: ComponentFixture<MenwatchesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MenwatchesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MenwatchesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
