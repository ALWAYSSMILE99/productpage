import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewdescription',
  templateUrl: './viewdescription.component.html',
  styleUrls: ['./viewdescription.component.css']
})
export class ViewdescriptionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
